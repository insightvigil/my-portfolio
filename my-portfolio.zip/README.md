## Typographix v2 🚀

In this version I started to transform a simple animation text reciver into a complete web project

### Applied technologies 🧑‍💻
- HTML
- CSS

### Features V1 ⚙️
- Interactive
- Animations
- FontAwesome 
- Google Fonts

### Features in this version ⚙️
- Web Page Structured
- Dark Mode

You can check it out live [here](https://insightvigil.github.io/typographix-v2).

### Contributors 🤝
- [Adrián Vigil](https://github.com/insightvigil)

#### Project developed during _The CSS Bootcamp_ by ZTM





# typographix-v2-
